import React from 'react'

import UserBar from './user/UserBar'

export default function App () {
    return <UserBar />
}
